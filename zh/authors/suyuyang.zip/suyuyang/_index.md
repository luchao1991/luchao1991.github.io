---
# Display name
title: 苏语扬

# Is this the primary user of the site?
superuser: false

# Role/position/tagline
role: 图情专硕

# Organizations/Affiliations to show in About widget
organizations:
- name: 河海大学
  url: http://www.hhu.edu.cn/

# Short bio (displayed in user profile at end of posts)
bio: 我的研究方向包括科学合作脱钩和劳动分工。

# Interests to show in About widget
interests:
- 科学合作脱钩
- 劳动分工

# Education to show in About widget
education:
  courses:
  - course: 图情专硕
    institution: 河海大学
    year: 2025
  - course: 信息资源管理学士
    institution: 天津财经大学
    year: 2021

# Social/Academic Networking
# For available icons, see: https://wowchemy.com/docs/getting-started/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "/#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: "mailto:swhywhy@163.com"  # For a direct email link, use "mailto:luchao91@hhu.edu.cn".

# Link to a PDF of your resume/CV.
# To use: copy your resume to `static/uploads/resume.pdf`, enable `ai` icons in `params.toml`, 
# and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: uploads/resume.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""
user_groups: ["研究生"]
# Highlight the author in author lists? (true/false)
highlight_name: true
---

📚苏语扬  | 研究“科研合作脱钩”的图情研究生｜Stata & Python & 数据分析｜试着把“谁不跟谁合作了”说清楚一点 | 剩下的时间都花在写 Python、画网络图、和回归模型较劲上👩‍💻

